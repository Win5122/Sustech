cd generated
python -m openapi_server