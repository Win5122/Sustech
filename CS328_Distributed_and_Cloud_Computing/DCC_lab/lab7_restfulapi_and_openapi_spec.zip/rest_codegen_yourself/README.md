# RESTful API - Codegen Yourself
Implementing a simple RESTful API server using Python Flask and OpenAPI Generator.

## Requirements
In this task, write an addition function to add an array of integers together and return the result. Define a RESTful API with the `calculator` tag to handle this functionality. Add this API to `hello_world.yaml`.

1. Modify the API specification YAML file. The new API has one array input and one integer output. For further information on which data types to choose, check this OpenAPI specification documentation by Swagger: https://swagger.io/specification/.
2. Use OpenAPI Generator to generate the server code template for Python Flask.
3. In the generated server template, implement the controller functions.
4. Run the server and test via `curl` or the Swagger UI page.

## Expected Output
Check with:
```bash
curl -X POST -H "Content-Type: application/json" \
  -d '{"vals": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}' \
  http://localhost:8080/calculator/add
```
The output should be:
```json
{
  "result": 55
}
```
