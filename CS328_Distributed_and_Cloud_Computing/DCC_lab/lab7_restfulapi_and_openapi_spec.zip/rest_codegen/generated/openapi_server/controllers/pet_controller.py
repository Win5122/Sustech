import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.add_pet_request_body import AddPetRequestBody  # noqa: E501
from openapi_server.models.delete_pet200_response import DeletePet200Response  # noqa: E501
from openapi_server.models.get_pet404_response import GetPet404Response  # noqa: E501
from openapi_server.models.pet import Pet  # noqa: E501
from openapi_server.models.update_pet_request_body import UpdatePetRequestBody  # noqa: E501
from openapi_server import util

from openapi_server.services.pet_service import PetService

pet_svc = PetService()

def add_pet():  # noqa: E501
    """add_pet

    Add a new pet. # noqa: E501

    :param add_pet_request_body: 
    :type add_pet_request_body: dict | bytes

    :rtype: Union[Pet, Tuple[Pet, int], Tuple[Pet, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        add_pet_request_body = AddPetRequestBody.from_dict(connexion.request.get_json())  # noqa: E501
    added = pet_svc.add_pet(name=add_pet_request_body.name, 
                            category=add_pet_request_body.category, 
                            status=add_pet_request_body.status)
    return added, 200


def delete_pet(pet_id):  # noqa: E501
    """delete_pet

    Delete a pet. # noqa: E501

    :param pet_id: 
    :type pet_id: int

    :rtype: Union[DeletePet200Response, Tuple[DeletePet200Response, int], Tuple[DeletePet200Response, int, Dict[str, str]]
    """
    res = pet_svc.delete_pet(pet_id)
    if res is None:
      return {"message": "no pet with id=%s" % pet_id}, 404
    else:
      return DeletePet200Response(res), 200


def get_all_pets():  # noqa: E501
    """get_all_pets

    Retrieve all pets. # noqa: E501


    :rtype: Union[List[Pet], Tuple[List[Pet], int], Tuple[List[Pet], int, Dict[str, str]]
    """
    pets = pet_svc.get_all_pets()
    return pets, 200


def get_pet(pet_id):  # noqa: E501
    """get_pet

    Get a specific pet by ID. # noqa: E501

    :param pet_id: 
    :type pet_id: int

    :rtype: Union[Pet, Tuple[Pet, int], Tuple[Pet, int, Dict[str, str]]
    """
    pet = pet_svc.get_pet(pet_id)
    if pet is None:
      return GetPet404Response(message="no pet with id=%s" % pet_id), 404
    else:
      return pet, 200


def update_pet(pet_id):  # noqa: E501
    """update_pet

    Update an existing pet by ID. # noqa: E501

    :param pet_id: 
    :type pet_id: int
    :param update_pet_request_body: 
    :type update_pet_request_body: dict | bytes

    :rtype: Union[Pet, Tuple[Pet, int], Tuple[Pet, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        update_pet_request_body = UpdatePetRequestBody.from_dict(connexion.request.get_json())  # noqa: E501
    pet = pet_svc.update_pet(pet_id, name=update_pet_request_body.name, 
                             category=update_pet_request_body.category, 
                             status=update_pet_request_body.status)
    if pet is None:
      return {"message": "no pet with id=%s" % pet_id}, 404
    else:
      return pet, 200
