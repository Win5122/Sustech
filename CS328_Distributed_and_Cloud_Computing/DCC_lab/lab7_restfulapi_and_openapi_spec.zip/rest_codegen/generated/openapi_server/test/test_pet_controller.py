import unittest

from flask import json

from openapi_server.models.add_pet_request_body import AddPetRequestBody  # noqa: E501
from openapi_server.models.delete_pet200_response import DeletePet200Response  # noqa: E501
from openapi_server.models.get_pet404_response import GetPet404Response  # noqa: E501
from openapi_server.models.pet import Pet  # noqa: E501
from openapi_server.models.update_pet_request_body import UpdatePetRequestBody  # noqa: E501
from openapi_server.test import BaseTestCase


class TestPetController(BaseTestCase):
    """PetController integration test stubs"""

    def test_add_pet(self):
        """Test case for add_pet

        
        """
        add_pet_request_body = {"name":"name","category":{"name":"Dogs","id":1},"status":"unknown"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        response = self.client.open(
            '/pets',
            method='POST',
            headers=headers,
            data=json.dumps(add_pet_request_body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_pet(self):
        """Test case for delete_pet

        
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/pets/{pet_id}'.format(pet_id=56),
            method='DELETE',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_all_pets(self):
        """Test case for get_all_pets

        
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/pets',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_pet(self):
        """Test case for get_pet

        
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/pets/{pet_id}'.format(pet_id=56),
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_pet(self):
        """Test case for update_pet

        
        """
        update_pet_request_body = {"name":"name","category":{"name":"Dogs","id":1},"status":"unknown"}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        response = self.client.open(
            '/pets/{pet_id}'.format(pet_id=56),
            method='PUT',
            headers=headers,
            data=json.dumps(update_pet_request_body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
