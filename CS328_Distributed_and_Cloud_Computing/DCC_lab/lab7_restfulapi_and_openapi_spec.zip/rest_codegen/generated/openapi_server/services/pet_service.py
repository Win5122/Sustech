from openapi_server.models.pet import Pet

class PetService:
  def __init__(self) -> None:
    self.pets: list[Pet] = {}
    
  def get_all_pets(self):
    return list(self.pets.values())
    
  def add_pet(self, name, category, status):
    new_pet = Pet(len(self.pets) + 1, category=category, name=name, status=status)
    self.pets[new_pet.id] = new_pet
    return new_pet
  
  def get_pet(self, pet_id):
    return self.pets.get(pet_id, None)
  
  def has_pet(self, pet_id):
    return pet_id in self.pets
  
  def update_pet(self, pet_id, name, category, status):
    if not self.has_pet(pet_id):
      return None
    self.pets[pet_id].name = name
    self.pets[pet_id].category = category
    self.pets[pet_id].status = status
    return self.pets[pet_id]
  
  def delete_pet(self, pet_id):
    if not self.has_pet(pet_id):
      return None
    del self.pets[pet_id]
    return pet_id
