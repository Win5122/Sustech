# RESTful API with Auto Backend Code Generation
Generating Python Flask code from an OpenAPI YAML file.

## Requirements
- Check `requirements.txt` in the `generated/` folder for Python requirements. Set up with `python -m pip install -r generated/requirements.txt`.
- Docker

## Update OpenAPI Specification File
The `petstore.yaml` records the API specifications of how the client will interact with the server. We will use this file to generate a code stub for our backend server.

For more information on OpenAPI Specification, check here: https://swagger.io/specification/.

## Generate and Implement the Backend Server
With [Docker](https://openapi-generator.tech/#try), we can use the OpenAPI Generator CLI to generate code stubs for the Python Flask backend server.

Run the following command:
```docker
docker run --rm -v ./:/app/ openapitools/openapi-generator-cli generate \
    -i /app/petstore.yaml \
    -g python-flask \
    -o /app/out/
```

The outputs will appear in the local `out/` directory. Now you can implement the API functions  based on this code structure. Basically, write something for the controllers inside `openapi_server/`.

## Run and Test the Backend Server
Check the `README.md` file inside the generated `out/` directory. To start a backend server for testing, simply run:

```bash
cd out
python -m openapi_server
```

By default, the server will serve on all network interfaces with port=`8080`. The available endpoints will be output by the server program. Below shows an output example:

```bash
(dncc) root@RAINBOW:/dncc-lab/rpc_rest/1_rest/1_codegen/out# python -m openapi_server
 * Serving Flask app '__main__' (lazy loading)
 * Environment: production
   WARNING: This is a development server. Do not use it in a production deployment.
   Use a production WSGI server instead.
 * Debug mode: off
WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:8080
 * Running on http://172.30.236.136:8080
Press CTRL+C to quit
```

In this example, there are 2 endpoints - http://127.0.0.1:8080 and http://172.30.236.136:8080. You can always start with `localhost:8080`.

To test the APIs, you can use `curl`:

```bash
# Get all pets
curl http://127.0.0.1:8080/pets

# Add a new pet
curl -X POST http://127.0.0.1:8080/pets \
     -H "Content-Type: application/json" \
     -d '{"name": "Bond", "category": {"id": 1, "name": "Dogs"}, "status": "healthy"}'
```

As an optional feature, you can also access `<BASE_URL>/ui` (e.g., http://127.0.0.1:8080/ui) to test the APIs in a rendered Swagger UI page.
