#include <mpi.h>
#include <stdio.h>

#include <unistd.h> // lib for sleep

int main(int argc, char** argv) {
    // Initialize the MPI environment. The two arguments to MPI Init are not
    // currently used by MPI implementations, but are there in case future
    // implementations might need the arguments.
    MPI_Init(NULL, NULL);

    // Get the rank of the process
    int world_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    
    // each processes sleeps for as many seconds as its rank
    sleep(world_rank); 

    // this stops the execution of the process untill all others have reache this spot
    MPI_Barrier(MPI_COMM_WORLD);

    // Print off a hello world message
    printf("Hello world from processor %s, rank %d out of %d processors \n",
     processor_name, world_rank, world_size);

    // Finalize the MPI environment. No more MPI calls can be made after this
    MPI_Finalize();
}
