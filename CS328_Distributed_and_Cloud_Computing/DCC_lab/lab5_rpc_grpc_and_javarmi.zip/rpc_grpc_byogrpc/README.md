# gRPC - Build Your Own gRPC Service
This is a task from the gRPC - Hello World example.

The students will be given the `local_procedure.py` file. The goal is to refactor the local procedure into a remote procedure hosted by the `AssistantService` gRPC service. For more info, check the `local_procedure.py` file directly.
