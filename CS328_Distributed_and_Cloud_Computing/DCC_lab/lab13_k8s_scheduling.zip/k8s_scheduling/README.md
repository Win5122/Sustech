# Kind for K8s - Pod Scheduling
An example for pod scheduling demonstration. Different scheduling methods are explored, specifically `nodeSelector`, pod affinity & anti-affinity, and taints & tolerations. A local multi-node K8s cluster is started using Kind where each node is represented as a docker container.

For more information, check the following official K8s documentation pages:
- [Assigning Pods to Nodes](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node)
- [Taints and Tolerations](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/)

## Requirements
- [Docker Desktop](https://docs.docker.com/desktop/)
- [`kubectl`](https://kubernetes.io/docs/reference/kubectl/)
- [Kind](https://kind.sigs.k8s.io/)

## Configure Cluster Template
Check `kind-config.yaml`. In this example, four nodes are created as a K8s cluster - one control plane and 5 worker nodes. In Kind, they are created as docker containers to mimic a multi-node cluster deployment on a single machine.

Extra labels can be pre-added to the cluster nodes from Kind ([doc](https://kind.sigs.k8s.io/docs/user/configuration/#extra-labels)). Extra taints can also be pre-configured for the cluster nodes in the same way.

## Create a Cluster via Kind
Run the following command:
```bash
kind create cluster --name dncc --config kind-config.yaml
```

The cluster will be created with the following output:
```text
kind create cluster --name dncc --config kind-config.yaml
Creating cluster "dncc" ...
 ✓ Ensuring node image (kindest/node:v1.31.2) 🖼 
 ✓ Preparing nodes 📦 📦 📦 📦  
 ✓ Writing configuration 📜 
 ✓ Starting control-plane 🕹️ 
 ✓ Installing CNI 🔌 
 ✓ Installing StorageClass 💾 
 ✓ Joining worker nodes 🚜 
Set kubectl context to "kind-dncc"
You can now use your cluster with:

kubectl cluster-info --context kind-dncc

Have a nice day! 👋
```

Verify the cluster on Docker Desktop, or via:
```bash
kind get clusters
```

The output will be the name of this cluster:
```text
dncc
```

## Switch to the Cluster Context for `kubectl`
When creating the K8s cluster, Kind automatically adds the cluster context to `kubectl` config. Find this context via `kubectl config get-contexts`:
```text
CURRENT   NAME        CLUSTER     AUTHINFO    NAMESPACE
*         kind-dncc   kind-dncc   kind-dncc
```

The asterisk (`*`) indicates the current context `kubectl` is working on. By default, Kind automatically switches `kubectl` to use the context of the latest created cluster. If not, manually switch to that context via:
```bash
kubectl config use-context kind-dncc
```

The output will be:
```text
Switched to context "kind-dncc".
```

## Explore Different Pod Scheduling Methods
### `nodeSelector`
As a startup, check the Kind configuration YAML file `kind-config.yaml` where several customized labels are added to the cluster nodes. These labels can also be [manually added via `kubectl`](https://kubernetes.io/docs/tasks/configure-pod-container/assign-pods-nodes/#add-a-label-to-a-node).

To retrieve the labels assigned to the cluster nodes, use either `kubectl get nodes --show-labels`, or:
```bash
kubectl get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.metadata.labels}{"\n"}{end}'
```
The second option outputs:
```text
dncc-control-plane      {"beta.kubernetes.io/arch":"amd64","beta.kubernetes.io/os":"linux","kubernetes.io/arch":"amd64","kubernetes.io/hostname":"dncc-control-plane","kubernetes.io/os":"linux","node-role.kubernetes.io/control-plane":"","node.kubernetes.io/exclude-from-external-load-balancers":""}
dncc-worker     {"attendance":"present","beta.kubernetes.io/arch":"amd64","beta.kubernetes.io/os":"linux","kubernetes.io/arch":"amd64","kubernetes.io/hostname":"dncc-worker","kubernetes.io/os":"linux","tier":"frontend"}
dncc-worker2    {"attendance":"absent","beta.kubernetes.io/arch":"amd64","beta.kubernetes.io/os":"linux","kubernetes.io/arch":"amd64","kubernetes.io/hostname":"dncc-worker2","kubernetes.io/os":"linux","tier":"frontend"}
dncc-worker3    {"attendance":"present","beta.kubernetes.io/arch":"amd64","beta.kubernetes.io/os":"linux","kubernetes.io/arch":"amd64","kubernetes.io/hostname":"dncc-worker3","kubernetes.io/os":"linux","tier":"frontend"}
dncc-worker4    {"attendance":"present","beta.kubernetes.io/arch":"amd64","beta.kubernetes.io/os":"linux","kubernetes.io/arch":"amd64","kubernetes.io/hostname":"dncc-worker4","kubernetes.io/os":"linux","tier":"backend"}
dncc-worker5    {"attendance":"present","beta.kubernetes.io/arch":"amd64","beta.kubernetes.io/os":"linux","kubernetes.io/arch":"amd64","kubernetes.io/hostname":"dncc-worker5","kubernetes.io/os":"linux"}
```

Note that for the workers, customized labels `tier` and `attendance` are specified. Specifically, worker 5 does not have `tier` specified. 

Now check `m0-node-selector.yaml` that specifies a deployment of 3 pod replicas with a node selector specification. The node selector ensures these pods managed by the deployment will only be scheduled to the nodes that have all label keys and values matched. Test with:
```
kubectl apply -f m0-node-selector.yaml
```

Then, examine which nodes these pods are scheduled to via:
```bash
kubectl get pods -o wide
```
The output is similar to below:
```text
NAME                            READY   STATUS    RESTARTS   AGE   IP           NODE           NOMINATED NODE   READINESS GATES
app-frontend-6b759cb5d6-hnqqj   1/1     Running   0          86s   10.244.5.3   dncc-worker3   <none>           <none>
app-frontend-6b759cb5d6-j54x9   1/1     Running   0          86s   10.244.1.5   dncc-worker    <none>           <none>
app-frontend-6b759cb5d6-r4hp5   1/1     Running   0          86s   10.244.1.4   dncc-worker    <none>           <none>
```

Note that worker 1 & 2 & 3 all have `tier=frontend` configured, but worker 2 is absent (i.e., `attendance=absent`). As a result, worker 2 is not assigned with any pod from this deployment. Either worker 1 or 3 has to take one more pod since we need to deploy 3 pods to only 2 matching nodes. Comparably, worker 4 & 5 do have `attendance=present`, but they do not have the matching label `tier` (either missing or not `frontend`). As a result, they are never considered a matching option.

### Pod Affinity & Anti-Affinity
Check `m1-pod-affinity.yaml` that specifies 3 different deployments representing different applications.

For `app-1` with 2 replicas, a pod anti-affinity rule inside `affinity.podAntiAffinity` is defined to ensure that the pod replicas in this deployment are never scheduled to the same node.

For `app-2` with 3 replicas, a pod affinity rule is defined inside `affinity.podAffinity` to ensure that the pods in this deployment should always be deployed together with the pods in `app-1`. Specifically, if `app-1` pod replicas are deployed to a certain group of nodes, then `app-2` pod replicas should also be deployed to this same group of nodes.

For `app-3` with 4 replicas, a pod anti-affinity rule is defined to ensure that the pods in this deployment should never be deployed together with the pods from `app-1` or `app-2`. Specifically, if `app-1` pod replicas are deployed to a certain group of nodes, then `app-3` pod replicas should not be deployed to this same group of nodes. Besides, another pod anti-affinity rule is defined to ensure that the pod replicas in this deployment are never scheduled to the same node.

Theoretically, in this K8s cluster with 5 worker nodes, the 2 pods from `app-1` will be deployed randomly to 2 of the worker nodes. Then, the 3 pods from `app-2` will also be deployed to these 2 worker nodes, where one of the nodes will possess 2 `app-2` pod replicas. Finally, the remaining 3 worker nodes will take 3 pod replicas from `app-3`, but there will be 1 `app-3` pod replica failing because it cannot be scheduled to any node.

Test this configuration via:
```bash
kubectl apply -f m1-pod-affinity.yaml
```
Then, examine which nodes these pods are scheduled to via:
```bash
kubectl get pods -o wide
```
The output is similar to below:
```text
NAME                     READY   STATUS    RESTARTS   AGE   IP            NODE           NOMINATED NODE   READINESS GATES
app-1-8658ff7c6d-j2c68   1/1     Running   0          6s    10.244.1.21   dncc-worker    <none>           <none>
app-1-8658ff7c6d-lg8q8   1/1     Running   0          6s    10.244.2.17   dncc-worker5   <none>           <none>
app-2-988579d8b-27n8q    1/1     Running   0          6s    10.244.2.16   dncc-worker5   <none>           <none>
app-2-988579d8b-c2kpb    1/1     Running   0          6s    10.244.2.18   dncc-worker5   <none>           <none>
app-2-988579d8b-ptgxz    1/1     Running   0          6s    10.244.1.20   dncc-worker    <none>           <none>
app-3-77c8f4877-24kg5    1/1     Running   0          6s    10.244.3.30   dncc-worker2   <none>           <none>
app-3-77c8f4877-db795    1/1     Running   0          6s    10.244.4.18   dncc-worker3   <none>           <none>
app-3-77c8f4877-jnqn9    0/1     Pending   0          6s    <none>        <none>         <none>           <none>
app-3-77c8f4877-zcb55    1/1     Running   0          6s    10.244.5.16   dncc-worker4   <none>           <none>
```

This output exactly aligns with the expectation.

The failed pod has no matching node to match because it needs to be in a different node. To resolve, the constraint that pod replicas in this deployment should not be deployed to the same node will be relaxed. This is achieved by moving this configuration section from `affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution` to `affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution`. Now the scheduler will try its best to deploy pod replicas to different nodes, but if not applicable, it will still deploy some pod replicas to the same node.

To update the pod anti-affinity rules, we need to first delete the current resources and recreate them. This is because pod scheduling rules are evaluated only when pods are created or rescheduled. Now run:
```bash
kubectl delete -f m1-pod-affinity.yaml
kubectl apply -f m1-pod-affinity.yaml
```

The output from `kubectl get pods -o wide` will now be like:
```text
NAME                     READY   STATUS    RESTARTS   AGE   IP            NODE           NOMINATED NODE   READINESS GATES
app-1-8658ff7c6d-94jx6   1/1     Running   0          3s    10.244.5.19   dncc-worker4   <none>           <none>
app-1-8658ff7c6d-xf86v   1/1     Running   0          3s    10.244.2.24   dncc-worker5   <none>           <none>
app-2-988579d8b-fj25c    1/1     Running   0          3s    10.244.5.21   dncc-worker4   <none>           <none>
app-2-988579d8b-lmfhv    1/1     Running   0          3s    10.244.2.25   dncc-worker5   <none>           <none>
app-2-988579d8b-zfq68    1/1     Running   0          3s    10.244.5.20   dncc-worker4   <none>           <none>
app-3-7b9b4bc87-42nr9    1/1     Running   0          3s    10.244.1.25   dncc-worker    <none>           <none>
app-3-7b9b4bc87-6559b    1/1     Running   0          3s    10.244.4.21   dncc-worker3   <none>           <none>
app-3-7b9b4bc87-f6b6j    1/1     Running   0          3s    10.244.4.22   dncc-worker3   <none>           <none>
app-3-7b9b4bc87-prjzl    1/1     Running   0          3s    10.244.3.36   dncc-worker2   <none>           <none>
```

Now all 4 `app-3` pod replicas can be deployed to the remaining 3 worker nodes, where one of the nodes will possess 2 `app-3` pod replicas.

### Taints and Tolerations
As a startup, uncomment the taints part in the Kind configuration YAML file `kind-config.yaml` so that one taint - `user=admin:NoSchedule` will be assigned to worker node 5. The taints can also be [manually introduced using `kubectl`](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/#concepts).

To retrieve the taints applied to the cluster nodes after creation, run:
```bash
kubectl get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.taints}{"\n"}{end}'
```

The output is as follow:
```text
dncc-control-plane      [{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane"}]
dncc-worker
dncc-worker2
dncc-worker3
dncc-worker4
dncc-worker5    [{"effect":"NoSchedule","key":"user","value":"admin"}]
```

Now check `m2-taint-toleration.yaml`that specifies 2 different deployments for different user levels. Both deployments request to deploy their pod replicas to the node with reserved purpose, using a node selector. The special deployment adds a toleration to its managed pods so that these pod replicas are able to tolerate the node taints, while the normal deployment does not include this toleration. As a result, the special deployment will be able to deploy its pod replicas to the reserved node, while the normal deployment will fail.

To test this configuration, run:
```bash
kubectl apply -f m2-taint-toleration.yaml
```
Then, examine which nodes these pods are scheduled to via:
```bash
kubectl get pods -o wide
```
The output is similar to below:
```text
NAME                           READY   STATUS    RESTARTS   AGE   IP           NODE           NOMINATED NODE   READINESS GATES
app-normal-8557598db7-6vj9p    0/1     Pending   0          5s    <none>       <none>         <none>           <none>
app-special-74d4f49658-dxtmn   1/1     Running   0          5s    10.244.5.2   dncc-worker5   <none>           <none>
```

This output exactly aligns with the expectation. Remember to remove the node taint after trying this sub-demo by commenting the relevant lines.

## Clean Up the Cluster After Exploration
**REMEMBER** to delete the cluster after playing with it. Do this via:
```bash
kind delete cluster --name dncc
```

The following outputs mark the process successful:
```text
Deleting cluster "dncc" ...
Deleted nodes: ["dncc-control-plane" "dncc-worker3" "dncc-worker2" "dncc-worker"]
```