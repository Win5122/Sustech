# Terraform - Local Quickstart
A Hello World example for using Terraform to manage a local file. Note that this is just used to demonstrate how to operate with Terraform. In reality, Terraform is majorly used to provision infrastructure resources.

## Requirements
- Terraform CLI: https://developer.hashicorp.com/terraform/tutorials/aws-get-started/install-cli.

## Write Configuration using HCL
Check `dncc_file/` folder. It contains a set of `.tf` files. Terraform will execute all these `.tf` files. File names are not important - they are just for the developer to understand what he/she is writting. We will consider this folder as a Terraform module.

Below explains the configurations in this module:
- `providers.tf`: specifies the providers required - the [`hashicorp/local` provider](https://registry.terraform.io/providers/hashicorp/local/latest) is used in this demo.
- `main.tf`: specifies the `local_file` resource named `my_file`. The file name and file content are configured for the resource. Check [this link](https://registry.terraform.io/providers/hashicorp/local/latest/docs/resources/file) to find the full schema for the `local_file` resource type. Several extra considerations:
  - The file content is specified as the value of an input variable configured in `variables.tf`.
  - The [`locals` block](https://developer.hashicorp.com/packer/docs/templates/hcl_templates/locals#locals-block) defines a set of local variables that can be used in other blocks.
  - The file name is set as a string combined with the local `folder_name` variable as well as the input variable `name`.
- `variables.tf`: specifies a set of input variables that can be configured by the users. There are different approaches to set the input variables upon TF applies, including:
  1. Explicit setting via command line: `terraform apply -var="content=hello"`
  2. Variable definition files: `terraform apply -var-file="testing.tfvars"`: naming the file as `terraform.tfvars` eliminates the need to set `-var-file`.
  3. Environment variables: `TF_VAR_content=greetings terraform apply`
  
  In this demo, `terraform.tfvars` is used.
- `terraform.tfvars`: sets the values of the input variables.
- `outputs.tf`: specifies the context for Terraform to [output](https://developer.hashicorp.com/terraform/language/values/outputs#declaring-an-output-value) after provisioning the infrastructure.

## Initialize & Prepare the Terraform Module
Inside that folder, run the following command:
```bash
terraform init
```

Upon successful initialization, the command-line output will be:
```text
Initializing the backend...
Initializing provider plugins...
- Finding hashicorp/local versions matching "2.5.2"...
- Installing hashicorp/local v2.5.2...
- Installed hashicorp/local v2.5.2 (signed by HashiCorp)
Terraform has created a lock file .terraform.lock.hcl to record the provider
selections it made above. Include this file in your version control repository
so that Terraform can guarantee to make the same selections by default when
you run "terraform init" in the future.

Terraform has been successfully initialized!

You may now begin working with Terraform. Try running "terraform plan" to see
any changes that are required for your infrastructure. All Terraform commands
should now work.

If you ever set or change modules or backend configuration for Terraform,
rerun this command to reinitialize your working directory. If you forget, other
commands will detect it and remind you to do so if necessary.
```

After initialization, the following files will be generated:
1. `.terraform/` folder: stores provider plugins, used module copies, etc.
2. `.terraform.lock.hcl`: locks the provider versions.

For more information, check the [official documentation](https://developer.hashicorp.com/terraform/cli/commands/init).

## Plan the Terraform Module
Inside that folder, run:
```bash
terraform plan
```

The command-line output will be:
```text
Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:

  # local_file.my_file will be created
  + resource "local_file" "my_file" {
      + content              = "Hello dncc. This is Terraform!"
      + content_base64sha256 = (known after apply)
      + content_base64sha512 = (known after apply)
      + content_md5          = (known after apply)
      + content_sha1         = (known after apply)
      + content_sha256       = (known after apply)
      + content_sha512       = (known after apply)
      + directory_permission = "0777"
      + file_permission      = "0777"
      + filename             = "../dncc_folder/configured_dncc_file"
      + id                   = (known after apply)
    }

Plan: 1 to add, 0 to change, 0 to destroy.

Changes to Outputs:
  + path = "../dncc_folder/configured_dncc_file"

───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

Note: You didn't use the -out option to save this plan, so Terraform can't guarantee to take exactly these actions if you run "terraform apply" now.
```

Note that TF plans do not actually modify the infrastructure, it is just like a preview operation.

## Apply the Terraform Module
Inside that folder, run:
```bash
terraform apply
```

Terraform will first generate an execution plan like using `terraform plan` and then wait for confirmation from the user to proceed to provisioning. During this procedure, a state lock file `.terraform.tfstate.lock.info` is generated in the module so that other people cannot write to the state file concurrently. This file is essentially a JSON:
```json
{
  "ID": "54f80078-ad90-da11-a570-b4dae6cd1f3c",
  "Operation": "OperationTypeApply",
  "Info": "",
  "Who": "root@RAINBOW",
  "Version": "1.10.2",
  "Created": "2024-12-17T18:04:40.294494287Z",
  "Path": "terraform.tfstate"
}
```

Now confirm by typing `yes` to the command line. Terraform will provision the specified file and record the state of this `local_file` resource to the `terraform.tfstate` file. The entire command-line output (along with the confirmation) will be:
```text
Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:

  # local_file.my_file will be created
  + resource "local_file" "my_file" {
      + content              = "Hello dncc. This is Terraform!"
      + content_base64sha256 = (known after apply)
      + content_base64sha512 = (known after apply)
      + content_md5          = (known after apply)
      + content_sha1         = (known after apply)
      + content_sha256       = (known after apply)
      + content_sha512       = (known after apply)
      + directory_permission = "0777"
      + file_permission      = "0777"
      + filename             = "../dncc_folder/configured_dncc_file"
      + id                   = (known after apply)
    }

Plan: 1 to add, 0 to change, 0 to destroy.

Changes to Outputs:
  + path = "../dncc_folder/configured_dncc_file"

Do you want to perform these actions?
  Terraform will perform the actions described above.
  Only 'yes' will be accepted to approve.

  Enter a value: yes

local_file.my_file: Creating...
local_file.my_file: Creation complete after 0s [id=d5057c22e81212273b0e425892ca84c33487f046]

Apply complete! Resources: 1 added, 0 changed, 0 destroyed.

Outputs:

path = "../dncc_folder/configured_dncc_file"
```

Note the TF outputs specified in the `outputs.tf` file have appeared in the last few lines.

The state file is also a JSON:
```json
{
  "version": 4,
  "terraform_version": "1.10.2",
  "serial": 5,
  "lineage": "e019ad5f-1c14-8f26-564b-d4453e815d3f",
  "outputs": {
    "path": {
      "value": "../dncc_folder/configured_dncc_file",
      "type": "string"
    }
  },
  "resources": [
    {
      "mode": "managed",
      "type": "local_file",
      "name": "my_file",
      "provider": "provider[\"registry.terraform.io/hashicorp/local\"]",
      "instances": [
        {
          "schema_version": 0,
          "attributes": {
            "content": "Hello dncc. This is Terraform!",
            "content_base64": null,
            "content_base64sha256": "dB3IdW/A8rgesbOFxWEB1vz15/wOG8jBx9JavYwhxlM=",
            "content_base64sha512": "/OwYqnSqze3zkRGQRnMMuKgyUTT6sttU1RG+8hlJYl0bpVR4NYXWetX9OK3RYGeu0m82Iewzru9+nwN1v2+3JA==",
            "content_md5": "bfe2be745c969068d72e8b289fc98164",
            "content_sha1": "d5057c22e81212273b0e425892ca84c33487f046",
            "content_sha256": "741dc8756fc0f2b81eb1b385c56101d6fcf5e7fc0e1bc8c1c7d25abd8c21c653",
            "content_sha512": "fcec18aa74aacdedf391119046730cb8a8325134fab2db54d511bef21949625d1ba554783585d67ad5fd38add16067aed26f3621ec33aeef7e9f0375bf6fb724",
            "directory_permission": "0777",
            "file_permission": "0777",
            "filename": "../dncc_folder/configured_dncc_file",
            "id": "d5057c22e81212273b0e425892ca84c33487f046",
            "sensitive_content": null,
            "source": null
          },
          "sensitive_attributes": [
            [
              {
                "type": "get_attr",
                "value": "sensitive_content"
              }
            ]
          ]
        }
      ]
    }
  ],
  "check_results": null
}
```

In the `resources` array, there is an object with a `local_file` resource type. All values from the resource schema as well as the specified outputs are recorded here. Note that a `terraform.tfstate.backup` file will also be generated to backup the previous version of state in case the TF apply fails.

## (Optional) Test Drift Detection & Management
Manually edit the created local file - modify its content. Then run `terraform apply` again. Terraform should be able to notice the difference between the expected file state in the configuration and the actual file status. The command-line output (along with the confirmation) is as follow:
```text
local_file.my_file: Refreshing state... [id=d5057c22e81212273b0e425892ca84c33487f046]

Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:

  # local_file.my_file will be created
  + resource "local_file" "my_file" {
      + content              = "Hello dncc. This is Terraform!"
      + content_base64sha256 = (known after apply)
      + content_base64sha512 = (known after apply)
      + content_md5          = (known after apply)
      + content_sha1         = (known after apply)
      + content_sha256       = (known after apply)
      + content_sha512       = (known after apply)
      + directory_permission = "0777"
      + file_permission      = "0777"
      + filename             = "../dncc_folder/configured_dncc_file"
      + id                   = (known after apply)
    }

Plan: 1 to add, 0 to change, 0 to destroy.

Do you want to perform these actions?
  Terraform will perform the actions described above.
  Only 'yes' will be accepted to approve.

  Enter a value: yes

local_file.my_file: Creating...
local_file.my_file: Creation complete after 0s [id=d5057c22e81212273b0e425892ca84c33487f046]

Apply complete! Resources: 1 added, 0 changed, 0 destroyed.

Outputs:

path = "../dncc_folder/configured_dncc_file"
```

Note that in the first few lines, Terraform first refreshes the states to match the actual file status. Then, it plans the execution - deciding that the file should be recreated to overwrite the original file, so that the file content can align with the configuration once again.

## Clean Up the Resources
After testing, remember to destroy the deployment:
```bash
terraform destroy
```

After confirmation, the local file will be deleted (the folder will remain) and the state file will be updated. The command-line output is as follow:
```text
Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the following symbols:
  - destroy

Terraform will perform the following actions:

  # local_file.my_file will be destroyed
  - resource "local_file" "my_file" {
      - content              = "Hello dncc. This is Terraform!" -> null
      - content_base64sha256 = "dB3IdW/A8rgesbOFxWEB1vz15/wOG8jBx9JavYwhxlM=" -> null
      - content_base64sha512 = "/OwYqnSqze3zkRGQRnMMuKgyUTT6sttU1RG+8hlJYl0bpVR4NYXWetX9OK3RYGeu0m82Iewzru9+nwN1v2+3JA==" -> null
      - content_md5          = "bfe2be745c969068d72e8b289fc98164" -> null
      - content_sha1         = "d5057c22e81212273b0e425892ca84c33487f046" -> null
      - content_sha256       = "741dc8756fc0f2b81eb1b385c56101d6fcf5e7fc0e1bc8c1c7d25abd8c21c653" -> null
      - content_sha512       = "fcec18aa74aacdedf391119046730cb8a8325134fab2db54d511bef21949625d1ba554783585d67ad5fd38add16067aed26f3621ec33aeef7e9f0375bf6fb724" -> null
      - directory_permission = "0777" -> null
      - file_permission      = "0777" -> null
      - filename             = "../dncc_folder/configured_dncc_file" -> null
      - id                   = "d5057c22e81212273b0e425892ca84c33487f046" -> null
    }

Plan: 0 to add, 0 to change, 1 to destroy.

Changes to Outputs:
  - path = "../dncc_folder/configured_dncc_file" -> null

Do you really want to destroy all resources?
  Terraform will destroy all your managed infrastructure, as shown above.
  There is no undo. Only 'yes' will be accepted to confirm.

  Enter a value: yes

local_file.my_file: Destroying... [id=d5057c22e81212273b0e425892ca84c33487f046]
local_file.my_file: Destruction complete after 0s

Destroy complete! Resources: 1 destroyed.
```

Check the state file again. Now that resource state has been removed:
```json
{
  "version": 4,
  "terraform_version": "1.10.2",
  "serial": 7,
  "lineage": "e019ad5f-1c14-8f26-564b-d4453e815d3f",
  "outputs": {},
  "resources": [],
  "check_results": null
}
```
