#!/usr/bin/env python3
import sys

word_count = {}

for line in sys.stdin: # read map results from stdin (sorted stdout of mappers)
    word, count = line.strip().split('\t')
    word_count[word] = word_count.get(word, 0) + int(count)

for word, count in word_count.items():
    print(f"{word:<10}\t{count}") # write <k2,v2> to stdout (final result -> will be writted to HDFS as a part)
