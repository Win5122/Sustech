#!/usr/bin/env python3
import sys

for line in sys.stdin: # read raw data from stdin
    words = line.strip().split()
    for word in words:
        print(f"{word}\t1") # write <k1,v1> to stdout
